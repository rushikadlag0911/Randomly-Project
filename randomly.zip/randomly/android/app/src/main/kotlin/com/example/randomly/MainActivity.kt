package com.example.randomly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
