import 'package:flutter/material.dart';
import 'screens/random_decision_screen.dart';

void main() {
  runApp(const RandomDecisionApp());
}

class RandomDecisionApp extends StatelessWidget {
  const RandomDecisionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Random Decision App',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: Colors.indigo[50],
      ),
      home: const RandomDecisionScreen(),
    );
  }
}
