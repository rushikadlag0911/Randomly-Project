import 'package:flutter/material.dart';

class InputField extends StatelessWidget {
  final TextEditingController nameController;
  final VoidCallback addName;

  const InputField(
      {super.key, required this.nameController, required this.addName});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: nameController,
            decoration: const InputDecoration(
              labelText: 'Enter a Name',
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),
        const SizedBox(width: 8.0),
        ElevatedButton(
          onPressed: addName,
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10.0),
            ),
          ),
          child: const Text('Add'),
        ),
      ],
    );
  }
}
