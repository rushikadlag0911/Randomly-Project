import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_fortune_wheel/flutter_fortune_wheel.dart';

class SpinWheel extends StatelessWidget {
  final StreamController<int> streamController;
  final List<String> names;
  final VoidCallback spinWheel;
  final bool isSpinning;

  const SpinWheel({
    super.key,
    required this.streamController,
    required this.names,
    required this.spinWheel,
    required this.isSpinning,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.0),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 8,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (names.length < 2)
            const Center(
              child: Text(
                'Add at least 2 names to spin the wheel!',
                style: TextStyle(fontSize: 16.0, color: Colors.indigo),
              ),
            )
          else
            FortuneWheel(
              selected: streamController.stream,
              items: [
                for (var name in names)
                  FortuneItem(
                    child: Text(
                      name,
                      style: const TextStyle(fontSize: 16.0),
                    ),
                  ),
              ],
            ),
          if (names.length >= 2)
            ElevatedButton(
              onPressed: spinWheel,
              style: ElevatedButton.styleFrom(
                shape: const CircleBorder(),
                padding: const EdgeInsets.all(20),
                backgroundColor: Colors.indigo,
              ),
              child: const Text(
                'SPIN',
                style: TextStyle(
                  fontSize: 16.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
