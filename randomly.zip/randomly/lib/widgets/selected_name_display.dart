import 'package:flutter/material.dart';

class SelectedNameDisplay extends StatelessWidget {
  final String? selectedName;
  final bool isSpinning;

  const SelectedNameDisplay(
      {super.key, this.selectedName, required this.isSpinning});

  @override
  Widget build(BuildContext context) {
    return isSpinning
        ? const Text(
            "Let's see who's that lucky person...",
            style: TextStyle(
              fontSize: 16.0,
              color: Colors.indigo,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          )
        : selectedName != null
            ? Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.indigo[100],
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Column(
                  children: [
                    Text(
                      'Selected Name:',
                      style:
                          TextStyle(fontSize: 18.0, color: Colors.indigo[900]),
                    ),
                    const SizedBox(height: 8.0),
                    Text(
                      selectedName!,
                      style: TextStyle(
                        fontSize: 24.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.indigo[700],
                      ),
                    ),
                  ],
                ),
              )
            : const SizedBox.shrink();
  }
}
