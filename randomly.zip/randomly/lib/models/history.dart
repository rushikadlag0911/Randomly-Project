class History {
  final String name;
  final String timestamp;

  History({
    required this.name,
    required this.timestamp,
  });

  // Factory method to create a History object from a map
  factory History.fromMap(Map<String, String> map) {
    return History(
      name: map['name']!,
      timestamp: map['timestamp']!,
    );
  }

  // Method to convert a History object to a map
  Map<String, String> toMap() {
    return {
      'name': name,
      'timestamp': timestamp,
    };
  }
}
