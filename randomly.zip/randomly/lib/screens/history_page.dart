// history_page.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import the intl package

class HistoryPage extends StatelessWidget {
  final List<Map<String, String>> history;

  const HistoryPage({super.key, required this.history});

  String _formatTimestamp(String timestamp) {
    // Parse the timestamp (assuming it's in ISO 8601 format or similar)
    final DateTime dateTime = DateTime.parse(timestamp);

    // Format it in 12-hour format with AM/PM
    final DateFormat dateFormat = DateFormat('hh:mm:ss a, MMM d, yyyy');
    return dateFormat.format(dateTime);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'History',
          style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        elevation: 4.0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.indigo[50]!, Colors.indigo[100]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: history.isEmpty
            ? const Center(
          child: Text(
            'No history available!',
            style: TextStyle(fontSize: 18.0, color: Colors.grey),
          ),
        )
            : ListView.builder(
          itemCount: history.length,
          itemBuilder: (context, index) {
            final record = history[index];
            final name = record['name']!;
            final timestamp = record['timestamp']!;
            final formattedTimestamp = _formatTimestamp(timestamp);

            return Card(
              margin: const EdgeInsets.symmetric(
                  vertical: 8.0, horizontal: 16.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              elevation: 4.0,
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.indigo,
                  child: Text(
                    '${index + 1}',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
                title: Text(
                  name,
                  style: const TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w500,
                    color: Colors.indigo,
                  ),
                ),
                subtitle: Text(
                  'Selected on: $formattedTimestamp',
                  style: const TextStyle(
                      fontSize: 14.0,
                      color: Colors.black,
                      fontWeight: FontWeight.bold),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
