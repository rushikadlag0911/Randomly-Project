import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../widgets/input_field.dart';
import '../widgets/name_list.dart';
import '../widgets/spin_wheel.dart';
import '../widgets/selected_name_display.dart';
import 'history_page.dart';

class RandomDecisionScreen extends StatefulWidget {
  const RandomDecisionScreen({super.key});

  @override
  RandomDecisionScreenState createState() => RandomDecisionScreenState();
}

class RandomDecisionScreenState extends State<RandomDecisionScreen> {
  final TextEditingController _nameController = TextEditingController();
  final List<String> _names = [];
  String? _selectedName;
  final StreamController<int> _streamController = StreamController<int>();
  bool _isSpinning = false;
  final List<Map<String, String>> _history = [];

  @override
  void dispose() {
    _streamController.close();
    super.dispose();
  }

  void _addName() {
    if (_nameController.text.trim().isNotEmpty) {
      final name = _nameController.text.trim().toUpperCase();
      if (!_names.any((existingName) => existingName.toUpperCase() == name)) {
        setState(() {
          _names.add(name);
          _nameController.clear();
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: Colors.indigo,
            content: Text('This name is already added!'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _clearNames() {
    setState(() {
      _names.clear();
      _selectedName = null;
    });
  }

  void _spinWheel() {
    if (_names.isNotEmpty) {
      setState(() {
        _isSpinning = true; // Start the spin animation
      });

      final random = Random();
      final randomIndex = random.nextInt(_names.length); // Pick a random name

      _streamController.add(randomIndex); // Add random index to the stream

      // Simulate a delay before displaying the result (for animation)
      Future.delayed(const Duration(seconds: 2), () {
        setState(() {
          _isSpinning = false; // Stop the spin animation
          _selectedName = _names[randomIndex]; // Set selected name
          // Add to history with timestamp
          _history.add({
            'name': _selectedName!,
            'timestamp': DateTime.now().toString(),
          });
        });
      });
    }
  }

  void _navigateToHistory() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HistoryPage(history: _history),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Random Decision App'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _clearNames,
            tooltip: 'Clear All Names',
          ),
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: _navigateToHistory,
            tooltip: 'View History',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            InputField(nameController: _nameController, addName: _addName),
            const SizedBox(height: 16.0),
            NameList(names: _names),
            const SizedBox(height: 16.0),
            SpinWheel(
              streamController: _streamController,
              names: _names,
              spinWheel: _spinWheel,
              isSpinning: _isSpinning,
            ),
            const SizedBox(height: 20.0),
            SelectedNameDisplay(
              selectedName: _selectedName,
              isSpinning: _isSpinning,
            ),
          ],
        ),
      ),
    );
  }
}
